(function (){
	function main(){
		var btn=document.getElementById("menu_btn");
		var mu=document.getElementById("menu");
		var isOpen=false;
		window.onresize=function()
		{
			if  (isOpen)
			{
				btn.setAttribute("class","mobile-menu mobile-menu-close");
				mu.setAttribute("class","mobile mobile-close");
				isOpen=false;				
			}
		}
		function open_meun()
		{
			if  (isOpen)
			{
				btn.setAttribute("class","mobile-menu mobile-menu-close");
				mu.setAttribute("class","mobile mobile-close");
				isOpen=false;				
			}
			else
			{	
				btn.setAttribute("class","mobile-menu mobile-menu-open");		
				mu.setAttribute("class","mobile mobile-open");		
				isOpen=true;				
			}
		}
		btn.onclick=open_meun;
		mu.onclick=open_meun;
	}
	window.onload=main;
})();